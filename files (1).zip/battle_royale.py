"""
Battle Royale NPC Game with OpenGL
Features:
- Multiple AI-controlled NPCs
- Shrinking safe zone
- 3D environment
- Combat system
- Last player standing wins
"""

import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random
import time

# Game constants
WORLD_SIZE = 100
NUM_NPCS = 20
INITIAL_ZONE_RADIUS = 80
ZONE_SHRINK_RATE = 0.1
PLAYER_SPEED = 0.5
NPC_SPEED = 0.3
BULLET_SPEED = 2.0
PLAYER_HEALTH = 100
NPC_HEALTH = 100

class Vector3:
    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z
    
    def distance_to(self, other):
        dx = self.x - other.x
        dy = self.y - other.y
        dz = self.z - other.z
        return math.sqrt(dx*dx + dy*dy + dz*dz)
    
    def normalize(self):
        length = math.sqrt(self.x**2 + self.y**2 + self.z**2)
        if length > 0:
            self.x /= length
            self.y /= length
            self.z /= length
        return self

class Bullet:
    def __init__(self, pos, direction, owner):
        self.pos = Vector3(pos.x, pos.y, pos.z)
        self.direction = Vector3(direction.x, direction.y, direction.z)
        self.direction.normalize()
        self.owner = owner
        self.active = True
        self.lifetime = 100
    
    def update(self):
        self.pos.x += self.direction.x * BULLET_SPEED
        self.pos.z += self.direction.z * BULLET_SPEED
        self.lifetime -= 1
        if self.lifetime <= 0:
            self.active = False
    
    def draw(self):
        glPushMatrix()
        glTranslatef(self.pos.x, self.pos.y + 1, self.pos.z)
        glColor3f(1.0, 1.0, 0.0)
        
        # Draw bullet as small sphere
        quadric = gluNewQuadric()
        gluSphere(quadric, 0.3, 8, 8)
        
        glPopMatrix()

class Entity:
    def __init__(self, x, z, is_player=False):
        self.pos = Vector3(x, 0, z)
        self.health = PLAYER_HEALTH if is_player else NPC_HEALTH
        self.is_player = is_player
        self.alive = True
        self.shoot_cooldown = 0
        self.color = [0.0, 1.0, 0.0] if is_player else [1.0, 0.0, 0.0]
        self.target = None
        self.stuck_timer = 0
        
    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.alive = False
    
    def can_shoot(self):
        return self.shoot_cooldown <= 0
    
    def shoot(self, target_pos, bullets):
        if self.can_shoot():
            direction = Vector3(
                target_pos.x - self.pos.x,
                0,
                target_pos.z - self.pos.z
            )
            bullets.append(Bullet(self.pos, direction, self))
            self.shoot_cooldown = 30
    
    def update_cooldown(self):
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
    
    def draw(self):
        if not self.alive:
            return
        
        glPushMatrix()
        glTranslatef(self.pos.x, self.pos.y, self.pos.z)
        
        # Body
        glColor3f(*self.color)
        quadric = gluNewQuadric()
        gluCylinder(quadric, 0.8, 0.8, 2.0, 16, 1)
        
        # Head
        glTranslatef(0, 0, 2.2)
        gluSphere(quadric, 0.6, 16, 16)
        
        # Health bar
        glTranslatef(0, 0, 1)
        glColor3f(1.0, 0.0, 0.0)
        glBegin(GL_QUADS)
        glVertex3f(-0.8, 0, 0)
        glVertex3f(0.8, 0, 0)
        glVertex3f(0.8, 0.2, 0)
        glVertex3f(-0.8, 0.2, 0)
        glEnd()
        
        # Health fill
        health_percent = self.health / (PLAYER_HEALTH if self.is_player else NPC_HEALTH)
        glColor3f(0.0, 1.0, 0.0)
        glBegin(GL_QUADS)
        glVertex3f(-0.8, 0, 0)
        glVertex3f(-0.8 + 1.6 * health_percent, 0, 0)
        glVertex3f(-0.8 + 1.6 * health_percent, 0.2, 0)
        glVertex3f(-0.8, 0.2, 0)
        glEnd()
        
        glPopMatrix()

class NPC(Entity):
    def __init__(self, x, z):
        super().__init__(x, z, False)
        self.state = "wander"  # wander, combat, flee
        self.move_timer = 0
        self.direction = Vector3(random.uniform(-1, 1), 0, random.uniform(-1, 1))
        self.direction.normalize()
        
    def ai_update(self, player, npcs, zone_center, zone_radius, bullets):
        self.update_cooldown()
        
        # Check if outside zone
        dist_from_center = self.pos.distance_to(zone_center)
        if dist_from_center > zone_radius:
            # Take damage outside zone
            self.take_damage(0.5)
            # Move toward zone center
            direction = Vector3(
                zone_center.x - self.pos.x,
                0,
                zone_center.z - self.pos.z
            )
            direction.normalize()
            self.pos.x += direction.x * NPC_SPEED
            self.pos.z += direction.z * NPC_SPEED
            return
        
        # Find nearest threat
        nearest_enemy = None
        nearest_distance = float('inf')
        
        if player.alive:
            dist = self.pos.distance_to(player.pos)
            if dist < nearest_distance:
                nearest_distance = dist
                nearest_enemy = player
        
        for npc in npcs:
            if npc != self and npc.alive:
                dist = self.pos.distance_to(npc.pos)
                if dist < nearest_distance and dist < 20:
                    nearest_distance = dist
                    nearest_enemy = npc
        
        # AI behavior
        if nearest_enemy and nearest_distance < 25:
            # Combat mode
            if nearest_distance > 15:
                # Move closer
                direction = Vector3(
                    nearest_enemy.pos.x - self.pos.x,
                    0,
                    nearest_enemy.pos.z - self.pos.z
                )
                direction.normalize()
                self.pos.x += direction.x * NPC_SPEED * 0.7
                self.pos.z += direction.z * NPC_SPEED * 0.7
            elif nearest_distance < 10:
                # Too close, back up
                direction = Vector3(
                    self.pos.x - nearest_enemy.pos.x,
                    0,
                    self.pos.z - nearest_enemy.pos.z
                )
                direction.normalize()
                self.pos.x += direction.x * NPC_SPEED * 0.5
                self.pos.z += direction.z * NPC_SPEED * 0.5
            
            # Shoot at enemy
            if random.random() < 0.05:  # 5% chance per frame
                self.shoot(nearest_enemy.pos, bullets)
        else:
            # Wander mode
            self.move_timer -= 1
            if self.move_timer <= 0:
                # Choose new random direction
                self.direction = Vector3(random.uniform(-1, 1), 0, random.uniform(-1, 1))
                self.direction.normalize()
                self.move_timer = random.randint(30, 120)
            
            # Move in chosen direction, but bias toward zone center
            move_dir = Vector3(self.direction.x, 0, self.direction.z)
            
            # Add bias toward zone center
            to_center = Vector3(
                zone_center.x - self.pos.x,
                0,
                zone_center.z - self.pos.z
            )
            to_center.normalize()
            
            move_dir.x = move_dir.x * 0.7 + to_center.x * 0.3
            move_dir.z = move_dir.z * 0.7 + to_center.z * 0.3
            move_dir.normalize()
            
            self.pos.x += move_dir.x * NPC_SPEED
            self.pos.z += move_dir.z * NPC_SPEED
        
        # Keep in bounds
        self.pos.x = max(-WORLD_SIZE, min(WORLD_SIZE, self.pos.x))
        self.pos.z = max(-WORLD_SIZE, min(WORLD_SIZE, self.pos.z))

class BattleRoyaleGame:
    def __init__(self):
        pygame.init()
        self.display = (1200, 800)
        pygame.display.set_mode(self.display, DOUBLEBUF | OPENGL)
        pygame.display.set_caption("Battle Royale - OpenGL")
        
        # OpenGL setup
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        
        # Lighting
        glLight(GL_LIGHT0, GL_POSITION, (0, 50, 0, 1))
        glLight(GL_LIGHT0, GL_AMBIENT, (0.3, 0.3, 0.3, 1))
        glLight(GL_LIGHT0, GL_DIFFUSE, (0.8, 0.8, 0.8, 1))
        
        # Projection
        gluPerspective(45, (self.display[0] / self.display[1]), 0.1, 500.0)
        
        # Game state
        self.player = Entity(0, 0, True)
        self.npcs = [NPC(random.uniform(-40, 40), random.uniform(-40, 40)) for _ in range(NUM_NPCS)]
        self.bullets = []
        self.zone_center = Vector3(0, 0, 0)
        self.zone_radius = INITIAL_ZONE_RADIUS
        self.zone_shrink_timer = 200
        self.camera_distance = 40
        self.camera_height = 30
        self.camera_angle = 0
        self.game_over = False
        self.winner = None
        self.clock = pygame.time.Clock()
        
    def handle_input(self):
        keys = pygame.key.get_pressed()
        
        # Player movement
        move_x = 0
        move_z = 0
        if keys[K_w]:
            move_z -= PLAYER_SPEED
        if keys[K_s]:
            move_z += PLAYER_SPEED
        if keys[K_a]:
            move_x -= PLAYER_SPEED
        if keys[K_d]:
            move_x += PLAYER_SPEED
        
        self.player.pos.x += move_x
        self.player.pos.z += move_z
        
        # Keep player in bounds
        self.player.pos.x = max(-WORLD_SIZE, min(WORLD_SIZE, self.player.pos.x))
        self.player.pos.z = max(-WORLD_SIZE, min(WORLD_SIZE, self.player.pos.z))
        
        # Camera rotation
        if keys[K_LEFT]:
            self.camera_angle -= 2
        if keys[K_RIGHT]:
            self.camera_angle += 2
        
        # Shooting
        if keys[K_SPACE] and self.player.can_shoot():
            # Shoot in camera direction
            angle_rad = math.radians(self.camera_angle)
            direction = Vector3(math.sin(angle_rad), 0, math.cos(angle_rad))
            self.player.shoot(
                Vector3(
                    self.player.pos.x + direction.x * 10,
                    0,
                    self.player.pos.z + direction.z * 10
                ),
                self.bullets
            )
    
    def update(self):
        if self.game_over:
            return
        
        self.player.update_cooldown()
        
        # Update NPCs
        alive_npcs = [npc for npc in self.npcs if npc.alive]
        for npc in alive_npcs:
            npc.ai_update(self.player, alive_npcs, self.zone_center, self.zone_radius, self.bullets)
        
        # Update bullets
        for bullet in self.bullets[:]:
            bullet.update()
            if not bullet.active:
                self.bullets.remove(bullet)
                continue
            
            # Check bullet collisions
            if bullet.owner != self.player and self.player.alive:
                if bullet.pos.distance_to(self.player.pos) < 1.5:
                    self.player.take_damage(20)
                    bullet.active = False
            
            for npc in alive_npcs:
                if bullet.owner != npc and npc.alive:
                    if bullet.pos.distance_to(npc.pos) < 1.5:
                        npc.take_damage(20)
                        bullet.active = False
                        break
        
        # Update zone
        self.zone_shrink_timer -= 1
        if self.zone_shrink_timer <= 0:
            self.zone_radius = max(10, self.zone_radius - ZONE_SHRINK_RATE)
            self.zone_shrink_timer = 5
        
        # Damage outside zone
        if self.player.alive:
            dist = self.player.pos.distance_to(self.zone_center)
            if dist > self.zone_radius:
                self.player.take_damage(0.5)
        
        # Check win condition
        alive_npcs = [npc for npc in self.npcs if npc.alive]
        if not self.player.alive:
            if len(alive_npcs) > 0:
                self.game_over = True
                self.winner = "NPCs"
        elif len(alive_npcs) == 0:
            self.game_over = True
            self.winner = "Player"
    
    def draw_ground(self):
        glDisable(GL_LIGHTING)
        
        # Draw grid
        glColor3f(0.2, 0.2, 0.2)
        glBegin(GL_LINES)
        for i in range(-WORLD_SIZE, WORLD_SIZE + 1, 10):
            glVertex3f(i, 0, -WORLD_SIZE)
            glVertex3f(i, 0, WORLD_SIZE)
            glVertex3f(-WORLD_SIZE, 0, i)
            glVertex3f(WORLD_SIZE, 0, i)
        glEnd()
        
        glEnable(GL_LIGHTING)
    
    def draw_zone(self):
        glDisable(GL_LIGHTING)
        glColor4f(0.0, 0.5, 1.0, 0.3)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        # Draw zone circle
        glBegin(GL_LINE_LOOP)
        for i in range(64):
            angle = i * 2 * math.pi / 64
            x = self.zone_center.x + self.zone_radius * math.cos(angle)
            z = self.zone_center.z + self.zone_radius * math.sin(angle)
            glVertex3f(x, 0.1, z)
        glEnd()
        
        glDisable(GL_BLEND)
        glEnable(GL_LIGHTING)
    
    def draw_hud(self):
        glDisable(GL_LIGHTING)
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.display[0], self.display[1], 0, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        
        # Draw text using pygame
        font = pygame.font.Font(None, 36)
        
        # Player health
        health_text = font.render(f"Health: {max(0, int(self.player.health))}", True, (0, 255, 0))
        self.render_text(health_text, 10, 10)
        
        # NPCs alive
        alive_count = sum(1 for npc in self.npcs if npc.alive)
        npc_text = font.render(f"NPCs Alive: {alive_count}", True, (255, 0, 0))
        self.render_text(npc_text, 10, 50)
        
        # Zone radius
        zone_text = font.render(f"Zone Radius: {int(self.zone_radius)}", True, (0, 150, 255))
        self.render_text(zone_text, 10, 90)
        
        # Game over
        if self.game_over:
            big_font = pygame.font.Font(None, 72)
            if self.winner == "Player":
                win_text = big_font.render("YOU WIN!", True, (0, 255, 0))
            else:
                win_text = big_font.render("GAME OVER", True, (255, 0, 0))
            self.render_text(win_text, self.display[0]//2 - 150, self.display[1]//2)
        
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
        glEnable(GL_LIGHTING)
    
    def render_text(self, text_surface, x, y):
        text_data = pygame.image.tostring(text_surface, "RGBA", True)
        glRasterPos2d(x, y)
        glDrawPixels(text_surface.get_width(), text_surface.get_height(),
                     GL_RGBA, GL_UNSIGNED_BYTE, text_data)
    
    def draw(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        # Camera position
        glLoadIdentity()
        cam_x = self.player.pos.x + self.camera_distance * math.sin(math.radians(self.camera_angle))
        cam_z = self.player.pos.z + self.camera_distance * math.cos(math.radians(self.camera_angle))
        gluLookAt(cam_x, self.camera_height, cam_z,
                  self.player.pos.x, 0, self.player.pos.z,
                  0, 1, 0)
        
        # Draw world
        self.draw_ground()
        self.draw_zone()
        
        # Draw entities
        self.player.draw()
        for npc in self.npcs:
            if npc.alive:
                npc.draw()
        
        # Draw bullets
        for bullet in self.bullets:
            bullet.draw()
        
        # Draw HUD
        self.draw_hud()
        
        pygame.display.flip()
    
    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_r and self.game_over:
                        self.__init__()  # Restart
            
            self.handle_input()
            self.update()
            self.draw()
            self.clock.tick(60)
        
        pygame.quit()

if __name__ == "__main__":
    print("Battle Royale - OpenGL")
    print("=" * 50)
    print("Controls:")
    print("  W/A/S/D - Move")
    print("  Arrow Keys - Rotate Camera")
    print("  Space - Shoot")
    print("  R - Restart (when game over)")
    print("  ESC - Quit")
    print("=" * 50)
    print("Objective: Be the last one standing!")
    print("Stay inside the blue zone or take damage!")
    print()
    
    game = BattleRoyaleGame()
    game.run()

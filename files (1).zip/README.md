# Battle Royale NPC Game (OpenGL)

A 3D battle royale game built with Python, PyOpenGL, and Pygame featuring AI-controlled NPCs, shrinking safe zones, and intense combat!

## Features

- **20 AI NPCs** with intelligent behavior (wandering, combat, zone awareness)
- **Shrinking safe zone** - stay inside or take damage
- **3D graphics** using OpenGL
- **Combat system** with shooting mechanics
- **Health bars** for all entities
- **Dynamic camera** that follows the player
- **Win condition** - last player/NPC standing

## Installation

### 1. Install Python
Make sure you have Python 3.8+ installed.

### 2. Install Dependencies
Open a terminal in the game folder and run:

```bash
pip install -r requirements.txt
```

Or install manually:
```bash
pip install pygame PyOpenGL PyOpenGL-accelerate
```

### 3. Run the Game
```bash
python battle_royale.py
```

## Controls

| Key | Action |
|-----|--------|
| **W/A/S/D** | Move player |
| **Arrow Keys** | Rotate camera |
| **Space** | Shoot |
| **R** | Restart (when game over) |
| **ESC** | Quit game |

## Gameplay

### Objective
Be the last one standing! Eliminate all 20 NPCs before they eliminate you.

### The Zone
- A blue circle marks the safe zone
- The zone shrinks over time
- Taking damage outside the zone? Move back in!
- NPCs also avoid the zone

### Combat
- Press **Space** to shoot in the direction you're facing
- Each hit deals 20 damage
- You and NPCs have 100 health
- NPCs will shoot back when they see you!

### NPC AI Behavior
NPCs have intelligent AI that:
- **Wanders** when no threats are nearby
- **Engages in combat** when enemies are detected
- **Maintains optimal distance** (not too close, not too far)
- **Avoids the zone** by moving toward the center
- **Shoots at targets** when in range

### Tips
- Use the camera rotation (arrow keys) to look around
- Keep moving to avoid NPC fire
- Stay aware of the zone - it keeps shrinking!
- NPCs will fight each other too - use that to your advantage
- Position yourself strategically before engaging

## Troubleshooting

### "No module named OpenGL"
```bash
pip install PyOpenGL PyOpenGL-accelerate
```

### Game runs slowly
- Close other applications
- The game targets 60 FPS but may vary by system

### Display issues
- Make sure your graphics drivers are up to date
- The game requires OpenGL support

## Game Stats

- **NPCs**: 20 AI opponents
- **Starting Zone Radius**: 80 units
- **Minimum Zone Radius**: 10 units
- **Player Health**: 100
- **NPC Health**: 100
- **Damage per Hit**: 20
- **Zone Damage**: 0.5 per frame (when outside)

## Have Fun!

Good luck surviving the battle royale! 🎮
